const A=document.querySelector('#app');
const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
const api=async(m,u,b)=>{const r=await fetch('/api/admin'+u,{method:m,headers:b instanceof FormData?{}:{'Content-Type':'application/json'},body:b?(b instanceof FormData?b:JSON.stringify(b)):undefined});
 const j=await r.json().catch(()=>({}));if(!r.ok){const e=new Error(j.error||'Erro');e.status=r.status;throw e}return j};
const field=(l,t='text',v='')=>{const w=el('div');const i=t==='textarea'?el('textarea'):el('input');if(t!=='textarea')i.type=t;if(t==='checkbox'){i.style.width='auto';i.checked=!!v}else i.value=v??'';if(t==='textarea')i.rows=6;
 const lb=el('label',null,l);w.append(lb,i);w.i=i;return w};
const val=f=>f.i.type==='checkbox'?f.i.checked:f.i.value;
function login(){A.replaceChildren();document.querySelector('#out').hidden=true;const e=field('E-mail','email'),p=field('Senha','password'),m=el('p','err'),b=el('button',null,'Entrar');
 b.onclick=async()=>{try{await api('POST','/login',{email:val(e),password:val(p)});home()}catch(x){m.textContent=x.message}};A.append(el('h2',null,'Painel administrativo'),e,p,b,m)}
async function home(){let me;try{me=await api('GET','/me')}catch{return login()}
 const o=document.querySelector('#out');o.hidden=false;o.onclick=async()=>{await api('POST','/logout',{});login()};
 A.replaceChildren(el('p','mut',`${me.posts} publicações (${me.drafts} rascunhos)`));const tabs=el('div','tabs'),body=el('div');A.append(tabs,body);
 for(const[n,f]of[['Posts',posts],['Grupos',groups],['Categorias',cats],['Config',conf]]){const b=el('button','sec',n);b.onclick=()=>f(body);tabs.append(b)}posts(body)}
async function upload(inp,set){const f=inp.files[0];if(!f)return;const fd=new FormData();fd.append('file',f);try{set((await api('POST','/upload',fd)).url)}catch(x){alert(x.message)}}
async function posts(B){B.replaceChildren();const nb=el('button',null,'+ Nova publicação');nb.onclick=()=>postForm(B);B.append(nb);
 for(const p of await api('GET','/posts')){const c=el('div','card');c.style.margin='10px 0';const r=el('div','row');
  r.append(el('b',null,`${p.pinned?'📌 ':''}${p.title}`),el('span','tag',p.status==='draft'?'RASCUNHO':p.category||''));const e=el('button','sec','Editar'),d=el('button','del','Excluir');
  e.onclick=()=>postForm(B,p);d.onclick=async()=>{if(confirm('Excluir esta publicação?')){await api('DELETE','/posts/'+p.id);home()}};c.append(r,e,' ',d);B.append(c)}}
async function postForm(B,p={}){B.replaceChildren();const cs=await(await fetch('/api/categories')).json();
 const t=field('Título','text',p.title),b=field('Descrição','textarea',p.body),ev=field('Data do evento (opcional)','text',p.event_date),pin=field('Fixar no topo','checkbox',p.pinned),im=field('Aviso importante','checkbox',p.important);
 const cat=el('select');cat.append(new Option('Sem categoria',''));cs.forEach(c=>cat.append(new Option(c.name,c.id,false,c.id===p.category_id)));
 let img=p.image||null;const fi=el('input');fi.type='file';fi.accept='image/jpeg,image/png,image/webp';const pv=el('img');pv.style.maxWidth='200px';if(img)pv.src=img;fi.onchange=()=>upload(fi,u=>{img=u;pv.src=u});
 const links=[...(p.links||[])];const lw=el('div');const draw=()=>{lw.replaceChildren();links.forEach((l,i)=>{const lb=el('input'),lu=el('input');lb.placeholder='Texto do botão';lu.placeholder='https://chat.whatsapp.com/...';lb.value=l.label;lu.value=l.url;lb.oninput=()=>l.label=lb.value;lu.oninput=()=>l.url=lu.value;const x=el('button','del','Remover link');x.onclick=()=>{links.splice(i,1);draw()};lw.append(lb,lu,x)})};draw();
 const al=el('button','sec','+ Link');al.onclick=()=>{links.push({label:'Entrar no grupo',url:''});draw()};
 const save=async st=>{try{const body={title:val(t),body:val(b),event_date:val(ev),pinned:val(pin),important:val(im),category_id:cat.value,image:img,links,status:st};p.id?await api('PUT','/posts/'+p.id,body):await api('POST','/posts',body);home()}catch(x){m.textContent=x.message}};
 const m=el('p','err');const pr=el('button','sec','Prévia');pr.onclick=()=>{const w=el('dialog');w.append(el('h2',null,val(t)||'(sem título)'),pv.cloneNode(),el('pre',null,val(b)));const c=el('button','sec','Fechar');c.onclick=()=>{w.close();w.remove()};w.append(c);document.body.append(w);w.showModal()};
 const sd=el('button','sec','Salvar rascunho'),sp=el('button',null,'Publicar');sd.onclick=()=>save('draft');sp.onclick=()=>save('published');
 B.append(t,b,el('label',null,'Categoria'),cat,ev,el('label',null,'Imagem (JPG/PNG/WebP, até 3 MB)'),fi,pv,el('h3',null,'Links'),lw,al,pin,im,el('br'),pr,' ',sd,' ',sp,m)}
async function groups(B){B.replaceChildren();const nb=el('button',null,'+ Novo grupo');nb.onclick=()=>gForm(B);B.append(nb);
 for(const g of await api('GET','/groups')){const c=el('div','card');c.style.margin='10px 0';const e=el('button','sec','Editar'),d=el('button','del','Excluir');e.onclick=()=>gForm(B,g);d.onclick=async()=>{if(confirm('Excluir grupo?')){await api('DELETE','/groups/'+g.id);groups(B)}};c.append(el('b',null,g.name+(g.active?'':' (inativo)')),el('p','mut',g.invite_url),e,' ',d);B.append(c)}}
function gForm(B,g={active:1}){B.replaceChildren();const n=field('Nome','text',g.name),d=field('Descrição','text',g.description),u=field('Link de convite do WhatsApp','url',g.invite_url),c=field('Categoria (ex.: Grupo principal, Avisos oficiais)','text',g.category),o=field('Ordem','number',g.sort_order||0),a=field('Ativo','checkbox',g.active);
 let icon=g.icon||null;const fi=el('input');fi.type='file';fi.accept='image/jpeg,image/png,image/webp';fi.onchange=()=>upload(fi,x=>icon=x);const m=el('p','err'),s=el('button',null,'Salvar');
 s.onclick=async()=>{try{const b={name:val(n),description:val(d),invite_url:val(u),category:val(c),sort_order:val(o),active:val(a),icon};g.id?await api('PUT','/groups/'+g.id,b):await api('POST','/groups',b);groups(B)}catch(x){m.textContent=x.message}};B.append(n,d,u,c,o,el('label',null,'Ícone (opcional)'),fi,a,s,m)}
async function cats(B){B.replaceChildren();const n=field('Nova categoria'),b=el('button',null,'Adicionar'),m=el('p','err');b.onclick=async()=>{try{await api('POST','/categories',{name:val(n)});cats(B)}catch(x){m.textContent=x.message}};B.append(n,b,m);
 for(const c of await(await fetch('/api/categories')).json()){const r=el('div','row',null);const x=el('button','del','Excluir');x.onclick=async()=>{await api('DELETE','/categories/'+c.id);cats(B)};r.append(el('span',null,c.name),x);B.append(r)}}
async function conf(B){B.replaceChildren();const s=await(await fetch('/api/settings')).json();const a=field('Nome do site','text',s.site_name),b=field('Frase de apresentação','text',s.tagline),c=field('Texto do rodapé','text',s.footer),x=el('button',null,'Salvar');
 x.onclick=async()=>{await api('PUT','/settings',{site_name:val(a),tagline:val(b),footer:val(c)});x.textContent='Salvo!'};B.append(a,b,c,x)}
home();
