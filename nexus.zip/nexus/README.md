# NEXUS — site oficial da aliança

**Stack:** Node.js + Express, SQLite (better-sqlite3, arquivo único, persistente, sem servidor de banco — ideal para hospedagem barata), frontend em HTML/CSS/JS puro (carrega rápido no celular).

## Instalar
```bash
npm install
cp .env.example .env      # edite SESSION_SECRET (comando de geração está no arquivo)
npm run create-admin      # cria o primeiro administrador (pede e-mail e senha de 12+ caracteres)
npm start                 # http://localhost:3000  | painel: /admin
```
O banco e as migrations são criados automaticamente na primeira execução (`db.js`). Não existe cadastro público de admin: novos admins só via `npm run create-admin -- --force` no terminal do servidor.

## Hospedar (VPS / Railway / Render com disco persistente)
1. Suba o projeto, rode `npm install --omit=dev`, configure o `.env` com `NODE_ENV=production`.
2. **Mantenha `data/` e `uploads/` em disco persistente** (backup regular desses dois diretórios).
3. Use `pm2 start server.js --name nexus` para manter online.
4. Domínio + HTTPS: aponte o DNS (registro A) para o servidor e use Nginx/Caddy como proxy para a porta 3000 com certificado Let's Encrypt (`caddy` faz HTTPS automático). Cookies seguros exigem HTTPS em produção.

## Segurança implementada
Senhas com bcrypt; sessões em cookie httpOnly/SameSite=Strict armazenadas no banco; rate limit de login (8 por 15 min); todas as rotas `/api/admin/*` exigem sessão no servidor; validação de campos e URLs (grupos só aceitam links do WhatsApp); upload validado por assinatura real do arquivo (JPG/PNG/WebP, 3 MB) com nome aleatório; Helmet + CSP; log de ações administrativas na tabela `audit`.
