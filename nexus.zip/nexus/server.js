require('dotenv').config();
const express=require('express'),session=require('express-session'),helmet=require('helmet'),rateLimit=require('express-rate-limit'),multer=require('multer'),bcrypt=require('bcryptjs'),path=require('path'),crypto=require('crypto'),fs=require('fs');
const db=require('./db');const Store=require('better-sqlite3-session-store')(session);
if(!process.env.SESSION_SECRET||process.env.SESSION_SECRET.length<32){console.error('Defina SESSION_SECRET (32+ chars) no .env');process.exit(1)}
const prod=process.env.NODE_ENV==='production';const UP=path.resolve(process.env.UPLOAD_DIR||'./uploads');fs.mkdirSync(UP,{recursive:true});
const app=express();app.set('trust proxy',1);
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],imgSrc:["'self'",'data:'],styleSrc:["'self'"],scriptSrc:["'self'"],objectSrc:["'none'"],frameAncestors:["'none'"]}}}));
app.use(express.json({limit:'100kb'}));
app.use(session({name:'nx.sid',secret:process.env.SESSION_SECRET,resave:false,saveUninitialized:false,store:new Store({client:db}),
 cookie:{httpOnly:true,sameSite:'strict',secure:prod,maxAge:8*3600e3}}));
app.use('/uploads',express.static(UP,{maxAge:'7d',setHeaders:r=>r.setHeader('X-Content-Type-Options','nosniff')}));
app.get('/admin',(q,s)=>s.sendFile(path.join(__dirname,'public','admin.html')));
app.use(express.static(path.join(__dirname,'public')));
// CSRF: mutações exigem JSON + cookie SameSite=Strict
app.use('/api',(q,s,n)=>{if(q.method!=='GET'&&!q.is('application/json')&&!q.path.endsWith('/upload'))return s.status(415).json({error:'Tipo inválido'});n()});
const S=(x,max)=>typeof x==='string'?x.trim().slice(0,max):'';
const url=(u,wa)=>{try{const p=new URL(u);return(p.protocol==='https:'&&(!wa||p.hostname==='chat.whatsapp.com'||p.hostname==='wa.me'))}catch{return false}};
const audit=(q,a,d)=>db.prepare('INSERT INTO audit(admin_id,action,detail) VALUES(?,?,?)').run(q.session.aid,a,d);
const admin=(q,s,n)=>q.session.aid?n():s.status(401).json({error:'Não autorizado'});
const bad=(s,m)=>s.status(400).json({error:m});
// ---------- público ----------
const pubPost=r=>({...r,links:JSON.parse(r.links||'[]')});
app.get('/api/posts',(q,s)=>{const page=Math.max(1,+q.query.page||1),lim=9,w=["status='published'"],a=[];
 if(q.query.q){w.push("(title LIKE ? OR body LIKE ?)");const k=`%${S(q.query.q,60)}%`;a.push(k,k)}
 if(+q.query.category){w.push('category_id=?');a.push(+q.query.category)}
 if(q.query.important==='1')w.push('important=1');
 const dir=q.query.order==='asc'?'ASC':'DESC';const W=w.join(' AND ');
 const total=db.prepare(`SELECT COUNT(*) c FROM posts WHERE ${W}`).get(...a).c;
 const rows=db.prepare(`SELECT p.*,c.name category FROM posts p LEFT JOIN categories c ON c.id=p.category_id WHERE ${W} ORDER BY pinned DESC,created_at ${dir} LIMIT ? OFFSET ?`).all(...a,lim,(page-1)*lim);
 s.json({posts:rows.map(pubPost),total,pages:Math.ceil(total/lim)})});
app.get('/api/posts/:id',(q,s)=>{const r=db.prepare("SELECT p.*,c.name category FROM posts p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=? AND status='published'").get(+q.params.id);r?s.json(pubPost(r)):s.status(404).json({error:'Não encontrado'})});
app.get('/api/groups',(q,s)=>s.json(db.prepare('SELECT * FROM groups WHERE active=1 ORDER BY sort_order,id').all()));
app.get('/api/categories',(q,s)=>s.json(db.prepare('SELECT * FROM categories ORDER BY name').all()));
app.get('/api/settings',(q,s)=>s.json(Object.fromEntries(db.prepare('SELECT * FROM settings').all().map(r=>[r.key,r.value]))));
// ---------- auth ----------
const loginLim=rateLimit({windowMs:15*60e3,limit:8,message:{error:'Muitas tentativas. Aguarde 15 min.'}});
const DUMMY=bcrypt.hashSync('x',12);
app.post('/api/admin/login',loginLim,(q,s)=>{const e=S(q.body.email,120).toLowerCase(),p=S(q.body.password,200);
 const u=db.prepare('SELECT * FROM admins WHERE email=?').get(e);const ok=bcrypt.compareSync(p,u?u.hash:DUMMY);
 if(!u||!ok)return s.status(401).json({error:'Credenciais inválidas'});
 q.session.regenerate(()=>{q.session.aid=u.id;audit(q,'login',e);s.json({ok:true})})});
app.post('/api/admin/logout',(q,s)=>q.session.destroy(()=>s.json({ok:true})));
app.get('/api/admin/me',admin,(q,s)=>s.json({ok:true,posts:db.prepare('SELECT COUNT(*) c FROM posts').get().c,drafts:db.prepare("SELECT COUNT(*) c FROM posts WHERE status='draft'").get().c}));
// ---------- posts ----------
function readPost(b){const t=S(b.title,150),body=S(b.body,10000);if(!t||!body)return'Título e texto são obrigatórios';
 const links=(Array.isArray(b.links)?b.links:[]).slice(0,6).map(l=>({label:S(l.label,40)||'Abrir',url:S(l.url,500)}));
 if(links.some(l=>!url(l.url)))return'Link inválido (use https://)';
 if(b.image&&!/^\/uploads\/[a-f0-9]{32}\.(jpg|png|webp)$/.test(b.image))return'Imagem inválida';
 return{t,body,links:JSON.stringify(links),image:b.image||null,cat:+b.category_id||null,status:b.status==='published'?'published':'draft',pinned:b.pinned?1:0,important:b.important?1:0,ev:S(b.event_date,25)||null}}
app.get('/api/admin/posts',admin,(q,s)=>s.json(db.prepare('SELECT p.*,c.name category FROM posts p LEFT JOIN categories c ON c.id=p.category_id ORDER BY created_at DESC').all().map(pubPost)));
app.post('/api/admin/posts',admin,(q,s)=>{const p=readPost(q.body);if(typeof p==='string')return bad(s,p);
 const r=db.prepare('INSERT INTO posts(title,body,image,category_id,status,pinned,important,event_date,links) VALUES(?,?,?,?,?,?,?,?,?)').run(p.t,p.body,p.image,p.cat,p.status,p.pinned,p.important,p.ev,p.links);
 audit(q,'post.create',`#${r.lastInsertRowid} ${p.t}`);s.json({id:r.lastInsertRowid})});
app.put('/api/admin/posts/:id',admin,(q,s)=>{const p=readPost(q.body);if(typeof p==='string')return bad(s,p);
 const r=db.prepare("UPDATE posts SET title=?,body=?,image=?,category_id=?,status=?,pinned=?,important=?,event_date=?,links=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").run(p.t,p.body,p.image,p.cat,p.status,p.pinned,p.important,p.ev,p.links,+q.params.id);
 if(!r.changes)return s.status(404).json({error:'Não encontrado'});audit(q,'post.update',`#${q.params.id}`);s.json({ok:true})});
app.delete('/api/admin/posts/:id',admin,(q,s)=>{db.prepare('DELETE FROM posts WHERE id=?').run(+q.params.id);audit(q,'post.delete',`#${q.params.id}`);s.json({ok:true})});
// ---------- grupos ----------
function readGroup(b){const n=S(b.name,80);if(!n)return'Nome obrigatório';if(!url(S(b.invite_url,300),true))return'Link deve ser https://chat.whatsapp.com/... ou https://wa.me/...';
 return[n,S(b.description,300),b.icon&&/^\/uploads\/[a-f0-9]{32}\.(jpg|png|webp)$/.test(b.icon)?b.icon:null,S(b.invite_url,300),S(b.category,40),parseInt(b.sort_order)||0,b.active?1:0]}
app.get('/api/admin/groups',admin,(q,s)=>s.json(db.prepare('SELECT * FROM groups ORDER BY sort_order,id').all()));
app.post('/api/admin/groups',admin,(q,s)=>{const g=readGroup(q.body);if(typeof g==='string')return bad(s,g);
 const r=db.prepare('INSERT INTO groups(name,description,icon,invite_url,category,sort_order,active) VALUES(?,?,?,?,?,?,?)').run(...g);audit(q,'group.create',g[0]);s.json({id:r.lastInsertRowid})});
app.put('/api/admin/groups/:id',admin,(q,s)=>{const g=readGroup(q.body);if(typeof g==='string')return bad(s,g);
 db.prepare('UPDATE groups SET name=?,description=?,icon=?,invite_url=?,category=?,sort_order=?,active=? WHERE id=?').run(...g,+q.params.id);audit(q,'group.update',`#${q.params.id}`);s.json({ok:true})});
app.delete('/api/admin/groups/:id',admin,(q,s)=>{db.prepare('DELETE FROM groups WHERE id=?').run(+q.params.id);audit(q,'group.delete',`#${q.params.id}`);s.json({ok:true})});
// ---------- categorias / config ----------
app.post('/api/admin/categories',admin,(q,s)=>{const n=S(q.body.name,40);if(!n)return bad(s,'Nome obrigatório');
 try{db.prepare('INSERT INTO categories(name) VALUES(?)').run(n);audit(q,'cat.create',n);s.json({ok:true})}catch{bad(s,'Categoria já existe')}});
app.delete('/api/admin/categories/:id',admin,(q,s)=>{db.prepare('DELETE FROM categories WHERE id=?').run(+q.params.id);audit(q,'cat.delete',`#${q.params.id}`);s.json({ok:true})});
app.put('/api/admin/settings',admin,(q,s)=>{for(const k of['site_name','tagline','footer']){if(typeof q.body[k]==='string')db.prepare('INSERT OR REPLACE INTO settings VALUES(?,?)').run(k,S(q.body[k],200))}audit(q,'settings','');s.json({ok:true})});
// ---------- upload (valida assinatura real do arquivo) ----------
const up=multer({storage:multer.memoryStorage(),limits:{fileSize:3*1024*1024,files:1}});
const sig=b=>b.slice(0,3).equals(Buffer.from([0xff,0xd8,0xff]))?'jpg':b.slice(0,4).equals(Buffer.from([0x89,0x50,0x4e,0x47]))?'png':(b.slice(0,4).toString()==='RIFF'&&b.slice(8,12).toString()==='WEBP')?'webp':null;
app.post('/api/admin/upload',admin,up.single('file'),(q,s)=>{const ext=q.file&&sig(q.file.buffer);if(!ext)return bad(s,'Envie JPG, PNG ou WebP até 3 MB');
 const name=crypto.randomBytes(16).toString('hex')+'.'+ext;fs.writeFileSync(path.join(UP,name),q.file.buffer);audit(q,'upload',name);s.json({url:'/uploads/'+name})});
app.use('/api',(q,s)=>s.status(404).json({error:'Rota inexistente'}));
app.use((e,q,s,n)=>{console.error(e);s.status(e.code==='LIMIT_FILE_SIZE'?400:500).json({error:e.code==='LIMIT_FILE_SIZE'?'Arquivo muito grande (máx. 3 MB)':'Erro interno'})});
app.listen(process.env.PORT||3000,()=>console.log('NEXUS no ar'));
