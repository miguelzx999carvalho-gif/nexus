const Database=require('better-sqlite3');const path=require('path');const fs=require('fs');
const file=path.resolve(process.env.DB_FILE||'./data/nexus.db');fs.mkdirSync(path.dirname(file),{recursive:true});
const db=new Database(file);db.pragma('journal_mode=WAL');db.pragma('foreign_keys=ON');
// migrations simples, versionadas por user_version
const M=[`
CREATE TABLE admins(id INTEGER PRIMARY KEY,email TEXT UNIQUE NOT NULL,hash TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE categories(id INTEGER PRIMARY KEY,name TEXT UNIQUE NOT NULL);
CREATE TABLE posts(id INTEGER PRIMARY KEY,title TEXT NOT NULL,body TEXT NOT NULL,image TEXT,category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
 status TEXT NOT NULL DEFAULT 'draft',pinned INTEGER DEFAULT 0,important INTEGER DEFAULT 0,event_date TEXT,links TEXT DEFAULT '[]',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE groups(id INTEGER PRIMARY KEY,name TEXT NOT NULL,description TEXT,icon TEXT,invite_url TEXT NOT NULL,category TEXT,sort_order INTEGER DEFAULT 0,active INTEGER DEFAULT 1);
CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE audit(id INTEGER PRIMARY KEY,admin_id INTEGER,action TEXT,detail TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
INSERT INTO categories(name) VALUES('Aviso'),('Evento'),('Recrutamento'),('Atualização'),('Comunicado');
INSERT INTO settings VALUES('site_name','NEXUS'),('tagline','Uma aliança. Um propósito. Sem limites.');`];
let v=db.pragma('user_version',{simple:true});
for(;v<M.length;v++){db.exec(M[v]);db.pragma(`user_version=${v+1}`)}
module.exports=db;
