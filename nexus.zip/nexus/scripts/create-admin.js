require('dotenv').config();const rl=require('readline').createInterface({input:process.stdin,output:process.stdout});
const bcrypt=require('bcryptjs');const db=require('../db');
const ask=q=>new Promise(r=>rl.question(q,r));
(async()=>{
 if(db.prepare('SELECT COUNT(*) c FROM admins').get().c>0&&process.argv[2]!=='--force'){console.log('Já existe administrador. Use --force para criar outro (só pelo terminal do servidor).');process.exit(1)}
 const email=(await ask('E-mail: ')).trim().toLowerCase();const pw=await ask('Senha (mín. 12 caracteres): ');rl.close();
 if(!/^\S+@\S+\.\S+$/.test(email)||pw.length<12){console.log('E-mail inválido ou senha curta.');process.exit(1)}
 db.prepare('INSERT INTO admins(email,hash) VALUES(?,?)').run(email,bcrypt.hashSync(pw,12));console.log('Administrador criado.');
})();
