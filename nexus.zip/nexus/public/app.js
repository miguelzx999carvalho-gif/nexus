const $=s=>document.querySelector(s);let page=1,pages=1;
const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
const get=async u=>(await fetch(u)).json();const fmt=d=>new Date(d.replace(' ','T')+(d.includes('Z')?'':'Z')).toLocaleString('pt-BR');
function card(p){const c=el('article','card'+(p.important?' imp':''));
 if(p.image){const i=el('img');i.src=p.image;i.loading='lazy';i.alt='';c.append(i)}
 c.append(el('div','tag',(p.pinned?'📌 ':'')+(p.important?'⚠ ':'')+(p.category||'Geral')),el('h3',null,p.title),el('p','mut',fmt(p.created_at)+(p.event_date?' · Evento: '+p.event_date:'')));
 const b=el('button','sec','Abrir');b.onclick=()=>open(p);c.append(b);return c}
function open(p){const d=$('#dlg');d.replaceChildren();if(p.image){const i=el('img');i.src=p.image;i.style.width='100%';d.append(i)}
 d.append(el('h2',null,p.title),el('pre',null,p.body));for(const l of p.links){const a=el('a','btn',l.label);a.href=l.url;a.target='_blank';a.rel='noopener noreferrer';a.style.margin='4px 4px 4px 0';d.append(a)}
 const x=el('button','sec','Fechar');x.onclick=()=>d.close();d.append(el('br'),x);d.showModal()}
async function load(reset){if(reset){page=1;$('#list').replaceChildren()}
 const q=new URLSearchParams({page,q:$('#q').value,category:$('#cat').value,order:$('#ord').value});const r=await get('/api/posts?'+q);pages=r.pages;
 r.posts.forEach(p=>$('#list').append(card(p)));$('#empty').hidden=r.total>0;$('#more').hidden=page>=pages}
(async()=>{
 const s=await get('/api/settings');$('#name').textContent=s.site_name;$('#tagline').textContent=s.tagline;$('#foot').textContent=`© ${new Date().getFullYear()} ${s.site_name}. ${s.footer||''}`;
 (await get('/api/categories')).forEach(c=>{const o=el('option',null,c.name);o.value=c.id;$('#cat').append(o)});
 const imp=await get('/api/posts?important=1');imp.posts.forEach(p=>$('#imp').append(card(p)));if(!imp.total)$('#imp').append(el('p','mut','Sem avisos importantes no momento.'));
 const g=await get('/api/groups');$('#gempty').hidden=g.length>0;
 g.forEach(x=>{const c=el('div','card');if(x.icon){const i=el('img','icon');i.src=x.icon;i.alt='';c.append(i)}
  const a=el('a','btn','ENTRAR NO GRUPO');a.href=x.invite_url;a.target='_blank';a.rel='noopener noreferrer';
  c.append(el('div','tag',x.category||''),el('h3',null,x.name),el('p','mut',x.description||''),a);$('#groups').append(c)});
 load(true)})();
let t;$('#q').oninput=()=>{clearTimeout(t);t=setTimeout(()=>load(true),300)};$('#cat').onchange=$('#ord').onchange=()=>load(true);$('#more').onclick=()=>{page++;load()};
